# MyFarm Desktop
This is the desktop version of MyFarm!
[![Gitter](https://badges.gitter.im/MyFarmApp-crops/community.svg)](https://gitter.im/MyFarmApp-crops/community?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge)
## Installing
Installing is simple! Open a terminal and run:
```console
curl -sL desktop.myfarmapp.tk | bash
```
